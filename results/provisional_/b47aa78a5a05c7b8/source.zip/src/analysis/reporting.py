"""Static scientific artifacts computed from saved, traceable experiments."""

import html
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from src.evaluation.benchmarking import load_run
from src.quality.validators import quality_report
from src.utils.config import ROOT, read_json, write_json


def error_analysis(run, benchmark):
    queries = {q["query_id"]: q for q in benchmark["queries"]}
    rows = []
    for result in run["per_query"]:
        if result["partition"] != "test":
            continue
        query = queries[result["query_id"]]
        top = result["ranking"][0] if result["ranking"] else None
        evidence_sets = {e["set_id"] for e in query["evidence"]}
        evidence_sections = {e["section"] for e in query["evidence"]}
        flags = []
        if top and query["answerable"]:
            if top["set_id"] not in evidence_sets:
                flags.append("different_label_set_at_rank_1")
            if top["section"] not in evidence_sections:
                flags.append("different_section_at_rank_1")
            if result["ndcg@10"] < 0.5:
                flags.append("low_provisional_relevance")
            if result["evidence_coverage@10"] == 0:
                flags.append("annotated_span_not_contained_in_top_10_chunks")
        if result["redundancy@10"] > 0.3:
            flags.append("section_redundancy")
        if not query["answerable"] and result["accepted_evidence"]:
            flags.append("unsupported_query_accepted")
        if query["answerable"] and not result["accepted_evidence"]:
            flags.append("answerable_query_rejected")
        rows.append(
            {
                "method": result["method"],
                "query_id": query["query_id"],
                "query": query["text"],
                "difficulty": query["difficulty"],
                "ndcg@10": result["ndcg@10"],
                "evidence_coverage@10": result["evidence_coverage@10"],
                "flags": flags,
                "top_result": top,
                "evidence_examples": query["evidence"][:2],
                "manual_review_required": [
                    "synonym/brand confusion",
                    "negation and safety qualifiers",
                    "dose/unit fidelity",
                    "clinical relevance",
                    "unjudged relevance",
                ],
            }
        )
    return rows


def benchmark_figures(run, output=None):
    output = Path(output or ROOT / "reports")
    output.mkdir(parents=True, exist_ok=True)
    table = pd.DataFrame(run["summary"])
    test = table[table.partition == "test"].set_index("method")
    figures = []
    fig, ax = plt.subplots(figsize=(10, 4))
    test[["ndcg@10", "recall@10", "precision@10", "evidence_coverage@10"]].plot.bar(ax=ax)
    ax.set(
        ylabel="Score (0–1)",
        xlabel="Retrieval method",
        ylim=(0, 1.05),
        title="Provisional held-out effectiveness" if run["provisional"] else "Held-out effectiveness",
    )
    ax.legend(loc="upper left", bbox_to_anchor=(1, 1))
    fig.tight_layout()
    fig.savefig(output / "retrieval_comparison.png", dpi=150)
    plt.close(fig)
    figures.append(
        {
            "path": "retrieval_comparison.png",
            "caption": "Section-level effectiveness uses incomplete draft qrels; passage evidence coverage is reported separately. "
            "No claim of clinical answer correctness follows from these scores.",
        }
    )
    fig, ax = plt.subplots(figsize=(8, 4))
    test[["latency_ms", "p95_latency_ms"]].plot.bar(ax=ax)
    ax.set(
        ylabel="Latency (milliseconds, log scale)",
        yscale="log",
        xlabel="Retrieval method",
        title="Warm-cache retrieval latency",
    )
    fig.tight_layout()
    fig.savefig(output / "retrieval_latency.png", dpi=150)
    plt.close(fig)
    figures.append(
        {
            "path": "retrieval_latency.png",
            "caption": "One sequential observation per query; includes ranking/reranking, excludes model loading, "
            "network query embeddings and index construction. Not a concurrent load test.",
        }
    )
    return figures


def _table(rows, columns=None):
    frame = pd.DataFrame(rows)
    return (
        frame[columns].to_html(index=False, escape=True, float_format=lambda x: f"{x:.4f}")
        if columns
        else frame.to_html(index=False, escape=True, float_format=lambda x: f"{x:.4f}")
    )


def write_reports(snapshot):
    quality = quality_report(snapshot)
    write_json(ROOT / "reports/data_quality.json", quality)
    eda = read_json(ROOT / "reports/eda.json")
    run = load_run()
    benchmark = read_json(ROOT / "data/benchmarks/benchmark.json")
    errors = error_analysis(run, benchmark)
    write_json(ROOT / "reports/error_analysis.json", errors)
    figures = benchmark_figures(run)
    status = (
        "PROVISIONAL — independent annotation review outstanding"
        if run["provisional"]
        else "Reviewed benchmark"
    )
    body = f"""<!doctype html><html lang="en"><meta charset="utf-8"><title>FDA retrieval scientific report</title>
<style>body{{max-width:1150px;margin:35px auto;font:16px/1.55 system-ui;color:#17243a;padding:0 20px}}
table{{border-collapse:collapse;font-size:12px;display:block;overflow:auto}}td,th{{border:1px solid #cbd5e1;padding:7px;text-align:left}}
th{{background:#e8eef7}}figure{{margin:25px 0}}img{{max-width:100%}}.status{{padding:16px;background:#fff1c7}}
code{{background:#eef2f6;padding:2px 5px}}h1,h2{{color:#164368}}</style>
<h1>FDA drug-label retrieval: comparative scientific report</h1><p class="status">{status}</p>
<p>Snapshot <code>{run["snapshot_id"]}</code>; benchmark <code>{run["benchmark_id"]}</code>;
run <code>{run["run_id"]}</code>. Data lineage: original response → record hash → document → section →
offset chunk → fingerprinted vector → collection → ranked result → source-bound evidence judgment.</p>
<h2>Acquisition and source contract</h2>
<p>MORVS is the primary acquisition source. The <a href="https://api.morvs.ai/openapi.json">inspected OpenAPI contract</a>
documents recent labels (limit 1–200) and substring name lookup, with no documented pagination, rate limit or authentication
requirement for these paths. HTTP 429 and transient server failures are retried with bounded backoff. Raw bodies are
content-addressed before parsing. The bounded recent feed and 12 purposive name lookups cannot support full-corpus claims.</p>
<p>Matching set identifiers are independently fetched from <a href="https://open.fda.gov/apis/drug/label/">openFDA labels</a>.
The full FDA records form a distinct supplementary experimental corpus. Same-effective-date prefix comparisons measure
third-party truncation; they do not establish clinical accuracy. Different dates remain version mismatches.
Label presence does not establish regulatory approval. Future effective dates are flagged, never corrected.</p>
<h2>Quality acceptance and observed indicators</h2>
{_table([{"indicator": k, "value": str(v)} for k, v in quality["summary"].items()])}
<p>Acceptance requires preserved response hashes, no unquarantined schema errors, and a nonempty full FDA corpus.
Missing fields remain missing. Summary snippets and third-party transformations are excluded from primary retrieval experiments.
The warnings table distinguishes malformed schema, future dates, encoding anomalies and fixed-width truncation candidates.</p>
<h2>Exploration and design implications</h2><ul>"""
    body += "".join(f"<li>{html.escape(t)}</li>" for t in eda["observations"]) + "</ul>"
    for figure in eda["figures"]:
        body += f'<figure><img src="{figure["path"]}" alt="Descriptive EDA"><figcaption>{html.escape(figure["caption"])}</figcaption></figure>'
    body += "<h2>Chunking and embeddings</h2>"
    body += "<p>Four section-bounded segmentation strategies (fixed tokens, recursive boundaries, section-aware, and linguistic sentence boundaries) "
    body += "are compared at 128/256/512 body tokens with 1/8 overlap. Linguistic semantic chunking is not an embedding discontinuity detector. "
    body += "Text and offsets remain exact; identity and section prefixes are derived metadata. Large source sections require bounded splitting. "
    body += "The development BM25 objective selects chunking; this favors lexical performance and is an acknowledged selection bias.</p>"
    body += _table(run["chunk_trials"])
    body += "<p>OpenAI hosted embedding candidates have no biomedical specialization established here. "
    body += "Provider weights cannot be pinned; model identifier, dimensionality, collection fingerprint, cached vectors and API tokens are recorded. "
    body += "Hosted service terms apply. Local biomedical encoders may be added with immutable revision, license and domain evaluation.</p>"
    body += _table(run["embedding_trials"])
    body += "<h2>Retrieval and development-only model selection</h2><p>Keyword ranking weights identity-term coverage 3 and body/section term coverage 1. "
    body += "BM25 uses casefolded Unicode words, preserved decimals and positive Robertson IDF. No stemming removes names or negation. "
    body += "Chroma uses explicit cosine HNSW settings and deterministic collection IDs. RRF sums weighted reciprocal ranks; the alternative fusion "
    body += "min-max normalizes each candidate score list before weighted addition. Missing candidates contribute zero. "
    body += "Cross-encoder reranking is a separate pinned MS MARCO model, Apache-2.0, with 512 model-token input truncation. "
    body += "Retrieval, fusion and reranking do not generate answers.</p>"
    body += _table(run["bm25_trials"]) + _table(run["fusion_trials"])
    body += f"<p>Locked development choice: <strong>{html.escape(run['selection']['preferred_on_dev'])}</strong>. "
    body += "The selection lock is written before held-out evaluation. Drug identities do not overlap dev/test queries; documents are the same frozen retrieval corpus. "
    body += "This tests query generalization across sampled drugs, not external-corpus generalization. Repeated development tuning can overfit.</p>"
    body += "<h2>Benchmark and relevance methodology</h2><p>80 authored intents: 25 easy, 30 medium and 25 hard; 72 answerable intents and 8 unsupported intents. "
    body += "Difficulty criteria are predefined in benchmark.json. Candidate evidence spans are located by independent section/phrase rules, never retrieval predictions. "
    body += "Rules and FDA source hashes verify literal evidence presence; human assessors must still independently judge relevance and ambiguity, add grade 1 partial "
    body += "and grade 0 irrelevant results, review pooled candidates, and adjudicate disagreements. Current source-backed draft qrels are not a gold standard. "
    body += "Unsupported requests concern evidence outside label scope. They are not assigned zero recall and mixed into relevance averages.</p>"
    body += "<p>Evaluation units are document-sections, deduplicated in original ranking order. Precision divides by K; recall divides by known relevant units. "
    body += "AP@K divides by min(K, known relevant units); MRR is cutoff-specific. nDCG uses gains 2^grade−1. Incomplete annotations bias metrics, especially recall and MAP. "
    body += "Separate evidence coverage counts annotated spans fully contained in top-K chunks; duplicate-section fraction exposes redundant passages. "
    body += "Threshold rejection is tuned only on development queries for balanced accuracy, then frozen.</p>"
    body += "<h2>Computed per-method results</h2>" + _table(
        run["summary"],
        [
            "method",
            "partition",
            "queries",
            "precision@10",
            "recall@10",
            "hit_rate@10",
            "mrr@10",
            "map@10",
            "ndcg@10",
            "evidence_coverage@10",
            "latency_ms",
            "p95_latency_ms",
            "unsupported_false_acceptance_rate",
        ],
    )
    for figure in figures:
        body += f'<figure><img src="{figure["path"]}" alt="Retrieval comparison"><figcaption>{html.escape(figure["caption"])}</figcaption></figure>'
    body += "<h2>Difficulty-stratified results</h2>" + _table(
        run["stratified"],
        ["method", "partition", "difficulty", "ndcg@10", "recall@10", "evidence_coverage@10", "latency_ms"],
    )
    body += "<h2>Paired statistical comparisons</h2><p>Paired cluster resampling groups queries by drug, preserving dependence among paraphrases. "
    body += "95% percentile bootstrap intervals and two-sided cluster sign-flip p-values are exploratory. Holm adjustment covers the displayed comparison family. "
    body += "Small cluster counts, incomplete qrels and development selection prevent confirmatory claims. Practical effects and latency must be considered together.</p>"
    body += _table(run["comparisons"])
    body += "<h2>Resources and practical trade-offs</h2>" + _table([run["resources"]])
    body += "<p>Chroma directory bytes include all embedding trials and SQLite/WAL files, not just the selected collection. "
    body += "RSS is a process observation, not peak memory. Throughput is reciprocal sequential warm latency, not concurrent capacity. "
    body += "Token usage is recorded; provider billing and hardware prices are not inferred.</p>"
    body += "<h2>Representative successes and failures</h2>"
    sample = sorted([r for r in errors if r["ndcg@10"] is not None], key=lambda r: r["ndcg@10"])
    for row in sample[:3] + sample[-3:]:
        body += f"<h3>{html.escape(row['method'])} · {html.escape(row['query_id'])}</h3><p>{html.escape(row['query'])}</p>"
        body += f"<p>Provisional nDCG@10: {row['ndcg@10']:.4f}; evidence coverage: {row['evidence_coverage@10']:.4f}; flags: {html.escape(', '.join(row['flags']))}</p>"
        if row["top_result"]:
            body += "<blockquote>" + html.escape(row["top_result"]["text_excerpt"]) + "</blockquote>"
    body += "<p>Machine flags compare label sets, sections, evidence containment, redundancy and unsupported acceptance. "
    body += "Wrong label-set flags can include clinically related but unjudged labels; they are candidate errors. Negation, brand equivalence, dose qualifiers, "
    body += "semantic false positives and clinical interpretation require independent manual analysis; they are not presented as verified diagnoses of failure.</p>"
    body += "<h2>Recommendation and validation status</h2>"
    body += f"<p>The empirical development objective selected <strong>{html.escape(run['selection']['preferred_on_dev'])}</strong> "
    body += "for this frozen exploratory run. The observed effectiveness/latency tables support local trade-off assessment. "
    body += "Independent annotation and adjudication remain required before selecting a scientifically validated final architecture. "
    body += "Hybrid retrieval and reranking are not presumed superior. No backend, frontend, deployment or answer generator is implemented.</p><ul>"
    body += "".join(f"<li>{html.escape(t)}</li>" for t in run["limitations"]) + "</ul></html>"
    (ROOT / "reports/scientific_report.html").write_text(body, encoding="utf-8")
    return ROOT / "reports/scientific_report.html"
