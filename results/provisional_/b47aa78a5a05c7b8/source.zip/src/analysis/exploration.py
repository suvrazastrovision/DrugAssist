"""Reusable descriptive EDA, explicit units, and figure captions."""

import re
from collections import Counter
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from src.preprocessing.chunking import chunk_documents, token_count
from src.retrieval.base import tokenize
from src.utils.config import ROOT, digest, write_json


def explore(snapshot, output=None):
    output = Path(output or ROOT / "reports")
    output.mkdir(parents=True, exist_ok=True)
    docs = snapshot["documents"]
    section_rows = [
        {
            "document_id": d["document_id"],
            "kind": d["kind"],
            "section": section,
            "characters": len(text),
            "tokens": token_count(text),
            "text_hash": digest(text),
            "abbreviations": len(re.findall(r"\b[A-Z]{2,8}\b", text)),
        }
        for d in docs
        for section, text in d["sections"].items()
    ]
    sections = pd.DataFrame(section_rows)
    document_rows = [
        {
            "document_id": d["document_id"],
            "set_id": d["set_id"],
            "kind": d["kind"],
            "effective_time": d["effective_time"],
            "product_type": " | ".join(d["metadata"]["product_type"]) or "Unknown",
            "name_available": bool(d["metadata"]["generic_name"] or d["metadata"]["brand_name"]),
            "ndc_available": bool(d["metadata"]["product_ndc"]),
            "rxcui_available": bool(d["metadata"]["rxcui"]),
            "characters": sum(map(len, d["sections"].values())),
            "section_count": len(d["sections"]),
        }
        for d in docs
    ]
    documents = pd.DataFrame(document_rows)
    official = [d for d in docs if d["kind"] == "fda_full"]
    terms = Counter(t for d in official for text in d["sections"].values() for t in tokenize(text))
    ingredients = Counter(t for d in docs for t in d["metadata"]["substance_name"])
    classes = Counter(t for d in official for t in d["metadata"]["pharm_class_epc"])
    aliases = [
        {
            "document_id": d["document_id"],
            "brand": d["metadata"]["brand_name"],
            "generic": d["metadata"]["generic_name"],
            "rxcui": d["metadata"]["rxcui"],
        }
        for d in official
    ]
    chunk_rows = []
    for strategy in ("fixed", "recursive", "section", "semantic"):
        for size, overlap in ((128, 16), (256, 32), (512, 64)):
            chunks = chunk_documents(official, strategy, size, overlap)
            lengths = pd.Series([c.token_count for c in chunks])
            chunk_rows.append(
                {
                    "strategy": strategy,
                    "size_tokens": size,
                    "overlap_tokens": overlap,
                    "chunks": len(chunks),
                    "median_tokens": float(lengths.median()),
                    "p95_tokens": float(lengths.quantile(0.95)),
                    "max_tokens": int(lengths.max()),
                }
            )
    # Near duplicates: word-shingle Jaccard for bounded document pairs, no removal.
    shingles = []
    for d in official:
        words = tokenize(" ".join(d["sections"].values()))
        shingles.append({tuple(words[i : i + 5]) for i in range(max(0, len(words) - 4))})
    near = []
    for i, a in enumerate(shingles):
        for j in range(i + 1, len(shingles)):
            b = shingles[j]
            score = len(a & b) / max(1, len(a | b))
            if score >= 0.8:
                near.append(
                    {
                        "left": official[i]["document_id"],
                        "right": official[j]["document_id"],
                        "word_5gram_jaccard": score,
                    }
                )
    report = {
        "snapshot_id": snapshot["manifest"]["snapshot_id"],
        "section_rows": section_rows,
        "document_rows": document_rows,
        "token_distribution_by_kind": sections.groupby("kind")["tokens"].describe().to_dict(),
        "top_terms": terms.most_common(40),
        "ingredient_frequency": ingredients.most_common(30),
        "pharmacologic_classes": classes.most_common(),
        "aliases": aliases,
        "candidate_chunk_distributions": chunk_rows,
        "near_duplicates": near,
        "exact_repeated_sections": int(sections["text_hash"].duplicated().sum()),
        "observations": [
            f"Observed {len(official)} full FDA records in a purposive bounded sample.",
            "Section and source-kind distributions require stratification because snippets and full records differ.",
            "Retain name aliases and source section metadata; do not map ontologies without separate validation.",
            "Candidate lengths describe segmentation only; choose retrieval parameters on development queries.",
            "Clinical outcomes, causation, and drug efficacy cannot be inferred from these counts.",
        ],
        "figures": [],
    }
    figures = [
        (
            "section_lengths.png",
            "Full FDA sections have heterogeneous token lengths; log scale avoids hiding short sections.",
        ),
        (
            "source_coverage.png",
            "Missing name/product identifiers vary by source representation and are not imputed.",
        ),
        (
            "chunk_candidates.png",
            "Chunk counts depend on strategy and size; counts do not measure retrieval effectiveness.",
        ),
        (
            "temporal.png",
            "Effective dates are source metadata, not ingestion dates; future values require investigation.",
        ),
        (
            "missingness.png",
            "Rows are records, columns are metadata availability indicators; source groups remain distinct.",
        ),
    ]
    fig, ax = plt.subplots(figsize=(10, 6))
    full = sections[sections.kind == "fda_full"]
    full.boxplot(column="tokens", by="section", ax=ax, rot=90, showfliers=False)
    ax.set(
        yscale="log",
        ylabel="cl100k_base tokens (log scale)",
        xlabel="FDA section",
        title="Section length distributions",
    )
    fig.suptitle("")
    fig.tight_layout()
    fig.savefig(output / figures[0][0], dpi=150)
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(8, 4))
    documents.groupby("kind")[["name_available", "ndc_available", "rxcui_available"]].mean().mul(
        100
    ).plot.bar(ax=ax)
    ax.set(
        ylabel="Records with attribute (%)",
        xlabel="Source representation",
        ylim=(0, 105),
        title="Metadata coverage",
    )
    fig.tight_layout()
    fig.savefig(output / figures[1][0], dpi=150)
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(8, 4))
    pd.DataFrame(chunk_rows).pivot(index="size_tokens", columns="strategy", values="chunks").plot.bar(ax=ax)
    ax.set(
        ylabel="Chunks (count)", xlabel="Maximum body tokens", title="Alternative segmentation configurations"
    )
    fig.tight_layout()
    fig.savefig(output / figures[2][0], dpi=150)
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(8, 4))
    for kind, group in documents.groupby("kind"):
        dates = pd.to_datetime(group.effective_time, format="%Y%m%d", errors="coerce").dropna()
        ax.hist(dates, bins=20, alpha=0.5, label=kind)
    ax.set(ylabel="Records (count)", xlabel="Label effective date", title="Label effective-date distribution")
    ax.legend()
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(output / figures[3][0], dpi=150)
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(6, 6))
    matrix = documents.sort_values("kind")[["name_available", "ndc_available", "rxcui_available"]]
    ax.imshow(matrix.astype(int), aspect="auto", cmap="Blues", vmin=0, vmax=1)
    ax.set(
        xticks=range(3),
        xticklabels=["Name", "NDC", "RxCUI"],
        ylabel="Record index (sorted by source)",
        title="Metadata availability (blue = present)",
    )
    fig.tight_layout()
    fig.savefig(output / figures[4][0], dpi=150)
    plt.close(fig)
    report["figures"] = [{"path": name, "caption": caption} for name, caption in figures]
    write_json(output / "eda.json", report)
    return report
