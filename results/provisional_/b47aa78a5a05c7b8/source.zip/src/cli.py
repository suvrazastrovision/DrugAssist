"""Research CLI only: no backend, frontend or answer generation."""

import argparse

from src.utils.config import ROOT, load_config, read_json, write_json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command",
        choices=["ingest", "analyze", "prepare-benchmark", "benchmark", "report", "verify-benchmark"],
    )
    parser.add_argument("--config")
    parser.add_argument("--snapshot")
    parser.add_argument(
        "--provisional",
        action="store_true",
        help="Explicitly allow draft qrels; results are not scientific validation",
    )
    parser.add_argument("--compare-embeddings", action="store_true")
    parser.add_argument("--no-tune-chunks", action="store_true")
    args = parser.parse_args()
    config = load_config(args.config)
    from src.ingestion.data_loader import ingest, load_snapshot

    if args.command == "ingest":
        snapshot = ingest(config)
        print(snapshot["manifest"]["snapshot_id"])
        return
    snapshot = load_snapshot(args.snapshot)
    if args.command == "analyze":
        from src.analysis.exploration import explore
        from src.quality.validators import quality_report

        quality = quality_report(snapshot)
        write_json(ROOT / "reports/data_quality.json", quality)
        if not all(quality["summary"]["acceptance"].values()):
            raise RuntimeError(
                "Data quality acceptance criteria failed; inspect reports before downstream analysis"
            )
        explore(snapshot)
        print("Wrote reports/data_quality.json, reports/eda.json and labeled figures")
    elif args.command == "prepare-benchmark":
        from src.evaluation.benchmark_data import make_benchmark

        benchmark = make_benchmark(snapshot)
        print(benchmark["benchmark_id"], benchmark["status"])
    elif args.command == "verify-benchmark":
        from src.evaluation.benchmark_data import validate_benchmark

        validate_benchmark(
            read_json(ROOT / "data/benchmarks/benchmark.json"),
            [d for d in snapshot["documents"] if d["kind"] == "fda_full"],
        )
        print("Reviewed benchmark validated against frozen FDA corpus")
    elif args.command == "benchmark":
        from src.evaluation.benchmarking import run_benchmark

        run = run_benchmark(
            snapshot, config, args.provisional, args.compare_embeddings, not args.no_tune_chunks
        )
        print("Completed", run["run_id"], "provisional:", run["provisional"])
    elif args.command == "report":
        from src.analysis.reporting import write_reports

        write_reports(snapshot)
        print("Wrote HTML scientific report")


if __name__ == "__main__":
    main()
