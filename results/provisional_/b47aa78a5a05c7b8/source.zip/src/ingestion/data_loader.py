"""Immutable snapshots and incremental cross-run record identity."""

from src.ingestion.api_client import APIClient, APIError
from src.preprocessing.normalization import normalize_record
from src.quality.validators import validate_record
from src.utils.config import ROOT, digest, read_json, utcnow, write_json


def ingest(config, client=None):
    settings = config["ingestion"]
    client = client or APIClient(timeout=settings["timeout"], retries=settings["retries"])
    discovery = client.discover()
    write_json(ROOT / "reports/api_contract.json", discovery)
    responses, source_records, fda_records, errors, comparisons = [], [], [], [], []
    recent, meta = client.recent(settings["recent_limit"])
    responses.append(meta)
    if not isinstance(recent.get("labels"), list):
        raise APIError("MORVS recent response schema changed")
    for record in recent["labels"]:
        source_records.append({"record": record, "provenance": meta, "kind": "recent_summary"})
    verified = set()
    for name in settings["lookup_names"]:
        try:
            payload, meta = client.lookup(name)
            if not isinstance(payload.get("labels"), list):
                raise APIError("MORVS lookup response schema changed")
            responses.append(meta)
        except APIError as exc:
            errors.append({"stage": "morvs_lookup", "name": name, "error": str(exc)})
            continue
        for record in payload["labels"]:
            source_records.append({"record": record, "provenance": meta, "kind": "lookup"})
        selected = [r for r in payload["labels"] if r.get("set_id") not in verified]
        for record in selected[: settings["fda_verify_per_name"]]:
            set_id = record.get("set_id")
            if not set_id:
                continue
            verified.add(set_id)
            try:
                official, fda_meta = client.fda_label(set_id)
                results = official.get("results", [])
                if not results:
                    raise APIError("FDA: no matching record")
                fda = results[0]
                responses.append(fda_meta)
                fda_records.append({"record": fda, "provenance": fda_meta, "kind": "fda_full"})
                same_version = fda.get("effective_time") == record.get("effective_time")
                for section in (
                    "indications_and_usage",
                    "dosage_and_administration",
                    "warnings",
                    "contraindications",
                    "adverse_reactions",
                    "drug_interactions",
                ):
                    third = record.get(section)
                    authority = "\n\n".join(fda.get(section, []))
                    comparisons.append(
                        {
                            "set_id": set_id,
                            "section": section,
                            "same_effective_time": same_version,
                            "morvs_length": len(third or ""),
                            "fda_length": len(authority),
                            "exact_agreement": bool(third) and third == authority,
                            "prefix_agreement": bool(third) and authority.startswith(third),
                            "observed_truncation": bool(third)
                            and authority.startswith(third)
                            and len(authority) > len(third),
                        }
                    )
            except APIError as exc:
                errors.append({"stage": "fda_verification", "set_id": set_id, "error": str(exc)})
        print(f"Acquired {name}: {len(payload['labels'])} MORVS labels", flush=True)
    # FDA full records remain a distinct, explicitly identified supplementary corpus.
    all_records = source_records + fda_records
    unique = {digest([r["kind"], r["record"]]): r for r in all_records}
    snapshot_id = digest(sorted(unique))[:20]
    folder = ROOT / "data/processed" / snapshot_id
    normalized, invalid = [], []
    for key, envelope in sorted(unique.items()):
        issues = validate_record(envelope["record"], envelope["kind"])
        if any(i["severity"] == "error" for i in issues):
            invalid.append({"record_hash": key, "issues": issues})
            continue
        normalized.append(normalize_record(envelope, snapshot_id))
    manifest = {
        "snapshot_id": snapshot_id,
        "created_at": utcnow(),
        "config": config,
        "scope": discovery["scope"],
        "responses": responses,
        "source_envelopes": len(all_records),
        "unique_records": len(unique),
        "duplicate_envelopes": len(all_records) - len(unique),
        "normalized_records": len(normalized),
        "quarantined_records": len(invalid),
        "errors": errors,
        "content_hash": digest(sorted(unique)),
        "record_ids": sorted(d["document_id"] for d in normalized),
    }
    if not (folder / "manifest.json").exists():
        write_json(folder / "records.json", list(unique.values()))
        write_json(folder / "documents.json", normalized)
        write_json(folder / "quarantine.json", invalid)
        write_json(folder / "verification.json", comparisons)
        write_json(folder / "manifest.json", manifest)
    write_json(ROOT / "data/processed/latest.json", {"snapshot_id": snapshot_id})
    return load_snapshot(snapshot_id)


def load_snapshot(snapshot_id=None):
    snapshot_id = snapshot_id or read_json(ROOT / "data/processed/latest.json")["snapshot_id"]
    folder = ROOT / "data/processed" / snapshot_id
    return {
        "manifest": read_json(folder / "manifest.json"),
        "documents": read_json(folder / "documents.json"),
        "records": read_json(folder / "records.json"),
        "verification": read_json(folder / "verification.json"),
    }
