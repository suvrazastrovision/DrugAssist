# FDA drug-label retrieval research

A modular research pipeline for MORVS acquisition, FDA source comparison, quality analysis, exploratory analysis, Chroma indexing and retrieval evaluation. The three notebooks import reusable modules under `src/`. There is no backend, frontend, deployment scaffolding or answer generation.

**Scientific status:** real data have been acquired and experimental retrieval is implemented. The 80-query benchmark contains curated intents and source-backed **draft** annotations. Independent human relevance review and adjudication are required before results qualify as scientific validation. The CLI refuses unreviewed benchmark evaluation unless `--provisional` is explicit.

## Setup

Python 3.11 or 3.12 and [uv](https://docs.astral.sh/uv/) are required. `uv.lock` pins transitive dependencies. `.env` is ignored; the existing `OPENAI_API_KEY` is loaded without printing or persisting it. `FDA_API_KEY` is optional. MORVS label paths were observed to permit keyless access.

```powershell
uv sync --locked --extra dev
uv run --locked fda-rag ingest
uv run --locked fda-rag analyze
uv run --locked fda-rag prepare-benchmark
uv run --locked fda-rag benchmark --provisional --compare-embeddings
uv run --locked fda-rag report
uv run --locked python scripts/create_notebooks.py
uv run --locked python scripts/execute_notebooks.py
uv run --locked pytest -q
uv run --locked ruff check src tests scripts
```

The first execution downloads tokenizer/model files. Embedding API calls incur provider usage; previously cached vectors are reused. The optional larger embedding candidate can be unavailable to an account and is reported explicitly. No synthetic vectors or fabricated benchmark scores replace failed real model calls.

Rerunning `ingest` can produce a different snapshot because upstream sources change. Use `--snapshot <id>` with subsequent commands to select a frozen corpus. Rebind query evidence only intentionally when changing snapshots. A completed experimental run is immutable; inspect its saved results rather than repeatedly tuning after observing test scores.

For append-only incremental maintenance, run `uv run python scripts/incremental_ingest.py --base <id>`. This acquires a new bounded sample and creates a deduplicated union snapshot with parent IDs. Historical label versions remain explicit. It does not imply feed pagination or complete FDA coverage, and it requires a new corpus/benchmark review before evaluation.

## Current dataset and lineage

The initial snapshot is `26fcf337a756edbf715b`: 200 MORVS recent summaries, 120 MORVS name-lookup records, and 24 separately fetched full FDA records. These are source representations, not 344 distinct drug products. Twelve drug-name lookups were purposively chosen; no population-representativeness claim is made.

- `data/raw/http/`: unchanged HTTP bodies and separate credential-free request metadata.
- `data/processed/<snapshot>/`: source envelopes, normalized documents, quarantine, FDA comparisons and immutable manifest.
- `data/benchmarks/benchmark.json`: 80 curated intents, 25 easy / 30 medium / 25 hard, including eight unsupported requests. Exact FDA evidence spans and source hashes accompany answerable query drafts.
- `data/cache/embeddings.sqlite3`, `data/chroma/`, `data/models/`: local vectors, persistent cosine HNSW collections and pinned model downloads.
- `results/<status>/<run>/`: chunk inventory, selection lock, per-query rankings, CSV metrics and complete run metadata.
- `reports/`: data-quality JSON, EDA JSON/figures, candidate error analyses and `scientific_report.html`.
- `notebooks/`: the three executed scientific notebooks.

Raw data, processed snapshots, model downloads and vector databases are excluded from Git because they can be large; they remain available locally. Benchmark evidence and computed reports are tracked project artifacts. To reproduce exact results elsewhere, transfer the frozen raw/processed corpus and embedding cache alongside the repository; live ingestion alone cannot guarantee identical upstream data.

`scripts/archive_run_source.py` verifies recorded source hashes and archives the exact experiment code/configuration as `source.zip` beside the completed run. `results/latest.json` points to the completed experiment; directories without `run.json` contain interrupted preparation attempts and are not completed results.

Every retrieved chunk carries the snapshot, document and label-set IDs; source-record and raw-body hashes; original section; exact character offsets; effective date; and FDA reference URL. `src.ingestion.integrity.verify_snapshot` verifies the actual raw bytes and record manifest without network access. The FDA URL can later resolve a newer label: frozen bytes and hashes establish the evaluated version.

## Verified source contract and limitations

The [MORVS OpenAPI specification](https://api.morvs.ai/openapi.json) documents `/api/v1/fda/labels/recent` with `limit <= 200`, `product_type`, and `manufacturer`, plus substring lookup `/api/v1/fda/labels/{name}`. It does not document label-feed pagination, authentication requirements for these paths, a complete export, rate limits or detailed response schemas. `reports/api_contract.json` preserves the inspected contract and source metadata. The [dataset descriptor](https://api.morvs.ai/datasets/fda-drug-labels) identifies openFDA as the upstream source.

Observed recent results contain snippets; name lookups can contain truncated sections. Matching same-date comparisons found 61 shortened MORVS section prefixes. Future effective dates and encoding anomalies are flagged, not corrected. FDA full text is kept as a separate supplementary corpus and used for the primary retrieval experiments. Agreement with [openFDA labeling](https://open.fda.gov/apis/drug/label/) is an observable comparison, not independent proof of clinical accuracy or FDA approval. Source-specific rights remain in force.

## Retrieval methods and experimental design

`config/default.json` defines the seed, acquisition bounds, tokenization, models, search settings and metrics. Four section-bounded chunking alternatives are compared at 128/256/512 body tokens with proportional overlap. Original text, quantities, units and negation remain unchanged; derived identity/section prefixes are added only to retrieval inputs.

The keyword baseline weights unique identity terms by 3 and body/section terms by 1. BM25 preserves decimals, biomedical names and negation. Dense retrieval uses explicit embeddings and persistent cosine Chroma HNSW storage. Hybrid methods compare weighted RRF against candidate-list min-max score normalization. A separate cross-encoder reranks hybrid candidates. All retrievers share the same query/filter interface.

Default embeddings use [`text-embedding-3-small`](https://developers.openai.com/api/docs/guides/embeddings), 1,536 dimensions, a general-domain hosted model whose provider weights cannot be pinned. Cached vectors make the local experiment repeatable. The optional larger hosted candidate uses 3,072 dimensions. The comparison also evaluates [`sentence-transformers/all-MiniLM-L6-v2`](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2), Apache-2.0, pinned to `1110a243fdf4706b3f48f1d95db1a4f5529b4d41`, with 384 dimensions and a 256-wordpiece limit. Its shorter input window can truncate FDA passages even when their OpenAI token count is within the chunk limit. It is a compact general-domain comparator, not a validated biomedical encoder. `LocalEmbedder` supports additional immutable-revision SentenceTransformer models; a biomedical model must be evaluated rather than presumed superior.

The reranker is [`cross-encoder/ms-marco-MiniLM-L6-v2`](https://huggingface.co/cross-encoder/ms-marco-MiniLM-L6-v2), Apache-2.0, pinned to commit `233902d25c440f23af6f7d6e94d2946bac0bee0a`. It is general-domain, runs on CPU, and truncates pair inputs to 512 model tokens. Biomedical generalization is not established by its training name or license.

There are 27 development queries and 53 test queries; answerable drug groups do not overlap. Chunking, BM25, embedding choice, fusion and method-specific abstention thresholds use development data only. Selection is written to `selection_lock.json` before held-out evaluation. The small repeatedly used development set still risks overfitting, and observed test results must not drive later tuning.

Primary metrics operate at the **document-section** level, collapse repeated units and use K=1,3,5,10. Precision divides by K, recall by known relevant units, AP@K by min(K,R), and nDCG uses gain `2^grade-1`. Incomplete judgments bias recall/MAP and other metrics. Separate passage-span containment and duplicate-section rates expose limitations hidden by section-level relevance. Unsupported queries are excluded from relevance averages and receive false-acceptance/rejection metrics using frozen development thresholds.

Paired bootstrap intervals resample drug clusters; paired cluster sign-flip tests and Holm corrections accompany planned nDCG@10 comparisons. With eight held-out drug groups and draft qrels, these are exploratory statistics. Warm-cache sequential latency excludes network query embeddings, model loading and indexing. Throughput is reciprocal mean latency, not a concurrent capacity test. Disk bytes and process RSS are observations, not peak resource guarantees.

Recorded API-token counts describe calls observed during candidate indexing/development in the successful process. Cached vectors from earlier interrupted preparations can have prior usage that is not captured by these counts; provider billing is the source for total charges.

## Annotation review and final evaluation

See [ANNOTATION_PROTOCOL.md](ANNOTATION_PROTOCOL.md). `scripts/build_query_intents.py` contains the authored information needs. Evidence-locating patterns are independent of retriever outputs but cannot replace relevance assessment. A query may have source-backed words without fully supporting its intended constraints. Read the complete relevant FDA sections, not only exported excerpts.

Finalization requires per-query reviewer identity, review timestamp, notes and reviewed status, an explicitly reviewed benchmark status, valid relevance grades and unchanged evidence spans. Use `uv run fda-rag verify-benchmark` to validate reviewed input before executing without `--provisional`. Never invent reviewer identities or set review flags on behalf of an absent human. Retain the draft run and document annotation changes; confirmatory claims require an untouched independently reviewed test set.

## Tests

Tests cover raw-body preservation before parse errors, retry behavior and credential-safe provenance; schema/date validation; exact chunk offsets, Unicode and token limits; lexical ranking and metadata filters; score-fusion arithmetic; real persistent Chroma idempotence and collection isolation; hand-calculated graded IR metrics; abstention and paired inference. Synthetic engineering fixtures are confined to tests and are never used as regulatory records or evaluation evidence.

API keys are excluded from Git and generated artifacts.
